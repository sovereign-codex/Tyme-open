
function openModule(module) {
  document.getElementById('module-view').src = `scrolls/${module}.html`;
}
