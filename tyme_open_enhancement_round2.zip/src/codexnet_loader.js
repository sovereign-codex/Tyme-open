// Load scrolls and authors
function loadScrolls() {
  // scroll loading logic
}