// JS logic for toggling between interfaces
function switchMode(mode) {
  console.log('Switching to', mode);
}