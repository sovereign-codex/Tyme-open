# AVOT sync stub
def sync_repo_to_avot():
    print('Syncing repo to AVOT')