## Installation Instructions

1. Upload to your Tyme-open repo.
2. Open in Replit or local environment.
3. Run `main.py` or use the HTML interface.