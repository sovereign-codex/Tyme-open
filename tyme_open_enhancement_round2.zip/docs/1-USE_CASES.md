## Use Cases

- Toggle between AVOT, HTFL, CodexNet.
- Live playback and scroll navigation.
- Real-time AVOT syncing to GitHub repos.